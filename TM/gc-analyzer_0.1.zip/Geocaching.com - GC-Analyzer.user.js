/* global $: true */
/* global waitForKeyElements: true */
/* global GM_xmlhttpRequest: true */
/* global GM_getValue: true */
/* global GM_setValue: true */
/* global unsafeWindow: true */
// jshint newcap:false
// jshint multistr:true

// ==UserScript==
// @name        Geocaching.com / GC-Analyzer
// @namespace   GCAnalyzer
// @description Adds links to GC-Analyzer at geocaching.com
// @include     http://www.geocaching.com/*
// @include     https://www.geocaching.com/*
// @author      frigidor
// @version     0.2
// @require     http://ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js
// ==/UserScript==

(function() {

    'use strict';

    // Don't run the script for iframes
    if (window.top == window.self) {
        Router();
    }

    function Router() {
        var path = window.location.pathname;
        
        if (path.match(/^\/geocache\/.*/) !== null) {
            Page_CachePage();
        } else if (path.match(/^\/seek\/cache_details\.aspx.*/) !== null) {
            Page_CachePage();
        }
    }

    function Page_CachePage() {
        var gccode = getGcCodeFromPage();
        $('#ctl00_ContentBody_CacheName').append(' <small><a href="http://gc-analyzer.frigidor.ch/'+gccode+'" target="_blank">analyze</small>');
    }

    /**
     * getGcCodeFromPage
     * @return string
     */
    function getGcCodeFromPage() {
        return $('#ctl00_ContentBody_CoordInfoLinkControl1_uxCoordInfoCode').html();
    }
}());
(function() {
    var path = window.location.pathname;

    // Don't run the script for iframes
    if (window.top == window.self) {
        Router();
    }

    function Router() {
        if (path.match(/^\/geocache\/.*/) !== null) {
            Page_CachePage();
        } else if (path.match(/^\/seek\/cache_details\.aspx.*/) !== null) {
            Page_CachePage();
        }
    }

    function Page_CachePage() {
        var gccode = getGcCodeFromPage();
        $('#ctl00_ContentBody_CacheName').append(' <small><a href="http://gc-analyzer.frigidor.ch/'+gccode+'" target="_blank">analyze</small>');
    }

    /**
     * getGcCodeFromPage
     * @return string
     */
    function getGcCodeFromPage() {
        return $('#ctl00_ContentBody_CoordInfoLinkControl1_uxCoordInfoCode').html();
    }

})();