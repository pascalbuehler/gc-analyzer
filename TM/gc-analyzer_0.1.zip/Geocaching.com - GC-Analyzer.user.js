// ==UserScript==
// @name         Geocaching.com / GC-Analyzer
// @namespace    GCAnalyzer
// @version      0.1
// @include      http://www.geocaching.com/*
// @include      https://www.geocaching.com/*
// @description  Adds links to GC-Analyzer at geocaching.com
// @author       frigidor
// @require      https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    var path = window.location.pathname;

    // Don't run the script for iframes
    if (window.top == window.self) {
        Router();
    }

    function Router() {
        if (path.match(/^\/geocache\/.*/) !== null) {
            Page_CachePage();
        } else if (path.match(/^\/seek\/cache_details\.aspx.*/) !== null) {
            Page_CachePage();
        }
    }

    function Page_CachePage() {
        var gccode = getGcCodeFromPage();
        $('#ctl00_ContentBody_CacheName').append(' <small><a href="http://gc-analyzer.frigidor.ch/'+gccode+'" target="_blank">analyze</small>');
    }

    /**
     * getGcCodeFromPage
     * @return string
     */
    function getGcCodeFromPage() {
        return $('#ctl00_ContentBody_CoordInfoLinkControl1_uxCoordInfoCode').html();
    }

})();